create trigger CATEGORY_AUTONUMERATION
	before insert
	on CATEGORY
	for each row
BEGIN
      :new.categoryID:=CATEGORY_SEQ.nextval;
    END;