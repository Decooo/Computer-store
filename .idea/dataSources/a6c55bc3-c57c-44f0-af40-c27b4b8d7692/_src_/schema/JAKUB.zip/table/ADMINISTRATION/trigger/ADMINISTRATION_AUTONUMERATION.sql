create trigger ADMINISTRATION_AUTONUMERATION
	before insert
	on ADMINISTRATION
	for each row
BEGIN
      :new.administrationID:=ADMINISTRATION_SEQ.nextval;
    END;