create trigger USERS_AUTONUMERATION
	before insert
	on USERS
	for each row
BEGIN
      :new.userID:=USERS_SEQ.nextval;
    END;