create trigger PRODUCT_AUTONUMERATION
	before insert
	on PRODUCT
	for each row
BEGIN
      :new.productID:=PRODUCT_SEQ.nextval;
    END;