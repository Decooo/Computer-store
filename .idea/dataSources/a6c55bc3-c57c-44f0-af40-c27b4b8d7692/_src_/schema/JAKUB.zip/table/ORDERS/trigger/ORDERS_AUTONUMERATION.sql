create trigger ORDERS_AUTONUMERATION
	before insert
	on ORDERS
	for each row
BEGIN
      :new.orderID:=ORDERS_SEQ.nextval;
    END;