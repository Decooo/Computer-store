create PACKAGE BODY P_CATEGORY
AS
PROCEDURE update_category(
    c_id   IN category.categoryid%type,
    c_name IN category.categoryName%type,
    c_desc IN category.categorydescription%type)
AS
BEGIN
  UPDATE category
  SET categoryname     =c_name,
    categorydescription=c_desc
  WHERE categoryID     =c_id;
END update_category;
PROCEDURE delete_category(
    c_id IN category.categoryid%type)
AS
BEGIN
  DELETE FROM category WHERE categoryID=c_id;
END delete_category;
PROCEDURE addcategory(
    c_categoryName        IN VARCHAR2,
    c_categoryDescription IN VARCHAR2 DEFAULT NULL)
AS
BEGIN
  INSERT
  INTO category
    (
      categoryName,
      categoryDescription
    )
    VALUES
    (
      c_categoryName,
      c_categoryDescription
    );
END addcategory;

PROCEDURE find_category_by_id
  (
    c_id IN category.categoryid%type,
    c_name OUT category.categoryname%type,
    c_desc OUT category.categorydescription%type
  )
IS
BEGIN
  SELECT categoryname,
    categorydescription
  INTO c_name,
    c_desc
  FROM category
  WHERE categoryid=c_id;
END;
END P_CATEGORY;