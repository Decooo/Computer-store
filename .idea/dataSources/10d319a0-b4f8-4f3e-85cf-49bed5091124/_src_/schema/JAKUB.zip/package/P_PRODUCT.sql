create PACKAGE P_PRODUCT
AS
  PROCEDURE add_product(
      p_name  IN product.productname%type,
      p_desc  IN product.productdescription%type,
      p_price IN product.productprice%type,
      picture IN product.picture%type,
      cat     IN product.categoryid%type);
  PROCEDURE delete_product(
      p_id IN product.productid%type);
  PROCEDURE find_product_by_id(
      p_id IN product.productid%type,
      p_name OUT product.productname%type,
      p_desc OUT product.productdescription%type,
      p_price OUT product.productprice%type,
      p_picture OUT product.picture%type,
      p_cat OUT product.categoryid%type);
  PROCEDURE update_product(
      p_id      IN product.productid%type,
      p_name    IN product.productname%type,
      p_desc    IN product.productdescription%type,
      p_price   IN product.productprice%type,
      p_picture IN product.picture%type,
      p_cat     IN product.categoryid%type);
  END P_PRODUCT;