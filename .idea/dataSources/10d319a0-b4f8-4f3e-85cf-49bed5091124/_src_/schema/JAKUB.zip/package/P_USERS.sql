create PACKAGE P_USERS AS 

  PROCEDURE add_client(
    c_firstname    IN client.firstname%TYPE,
    c_lastname     IN client.lastname%TYPE,
    c_emailaddress IN client.emailaddress%TYPE,
    c_street       IN client.street%TYPE,
    c_numberhouse  IN client.numberhouse%TYPE,
    c_postcode     IN client.postcode%TYPE,
    c_city         IN client.city%TYPE,
    c_clientID OUT client.clientID%TYPE,
    u_username IN users.username%TYPE,
    u_password IN users.password%TYPE);
PROCEDURE GET_USER
  (
      U_USERNAME IN OUT VARCHAR2,
      U_ID OUT NUMBER
    , U_PASSWORD OUT VARCHAR2
    , U_CLIENTID OUT NUMBER
    , U_ROLE OUT varchar2
  );
  PROCEDURE get_user_id(
    u_id OUT users.userid%type,
    u_username IN users.username%type);
END P_USERS;