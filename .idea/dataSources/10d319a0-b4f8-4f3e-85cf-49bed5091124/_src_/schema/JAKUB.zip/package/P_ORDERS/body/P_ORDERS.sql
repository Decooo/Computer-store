create PACKAGE BODY P_ORDERS
AS
PROCEDURE add_orders(
    o_userid IN orders.userid%type,
    o_price  IN orders.totalprice%type,
    o_orderid OUT orders.orderid%type )
AS
BEGIN
  INSERT
  INTO orders
    (
      orderdate,
      userid,
      totalprice
    )
    VALUES
    (
      get_date(),
      o_userid,
      o_price
    )
  RETURNING orderid
  INTO o_orderid;
END add_orders;
PROCEDURE add_orderdetail
  (
    o_orderid   IN orderdetails.orderid%type,
    o_productid IN orderdetails.productid%type,
    o_quantity  IN orderdetails.quantity%type,
    o_price     IN orderdetails.price%type
  )
IS
BEGIN
  INSERT
  INTO orderdetails
    (
      orderid,
      productid,
      quantity,
      price
    )
    VALUES
    (
      o_orderid,
      o_productid,
      o_quantity,
      o_price
    );
END ;
END P_ORDERS;