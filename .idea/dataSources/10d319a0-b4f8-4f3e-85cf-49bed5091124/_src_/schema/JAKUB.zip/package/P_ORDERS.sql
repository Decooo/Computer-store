create PACKAGE P_ORDERS
AS
  PROCEDURE add_orders(
      o_userid IN orders.userid%type,
      o_price  IN orders.totalprice%type,
      o_orderid OUT orders.orderid%type );
  PROCEDURE add_orderdetail(
      o_orderid   IN orderdetails.orderid%type,
      o_productid IN orderdetails.productid%type,
      o_quantity  IN orderdetails.quantity%type,
      o_price     IN orderdetails.price%type);
END P_ORDERS;