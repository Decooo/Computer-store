create PACKAGE BODY P_PRODUCT AS

  PROCEDURE add_product(
    p_name  IN product.productname%type,
    p_desc  IN product.productdescription%type,
    p_price IN product.productprice%type,
    picture IN product.picture%type,
    cat     IN product.categoryid%type) AS
  BEGIN
    INSERT
  INTO product
    (
      productname,
      productDescription,
      productprice,
      picture,
      categoryid
    )
    VALUES
    (
      p_name,
      p_desc,
      p_price,
      picture,
      cat
    );
  END add_product;

PROCEDURE delete_product(
    p_id IN product.productid%type)
AS
BEGIN
  DELETE FROM product WHERE productID=p_id;
END;

PROCEDURE find_product_by_id(
    p_id IN product.productid%type,
    p_name OUT product.productname%type,
    p_desc OUT product.productdescription%type,
    p_price OUT product.productprice%type,
    p_picture OUT product.picture%type,
    p_cat OUT product.categoryid%type)
IS
BEGIN
  SELECT productname,
    productdescription,
    productprice,
    picture,
    categoryid
  INTO p_name,
    p_desc,
    p_price,
    p_picture,
    p_cat
  FROM product
  WHERE productid=p_id;
END;

PROCEDURE update_product(
    p_id      IN product.productid%type,
    p_name    IN product.productname%type,
    p_desc    IN product.productdescription%type,
    p_price   IN product.productprice%type,
    p_picture IN product.picture%type,
    p_cat     IN product.categoryid%type)
AS
BEGIN
  UPDATE product
  SET productname     =p_name,
    productdescription=p_desc,
    productprice      =p_price,
    picture           =p_picture,
    categoryid        =p_cat
  WHERE productID     =p_id;
END;

END P_PRODUCT;