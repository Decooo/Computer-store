create PACKAGE P_CATEGORY
AS
  PROCEDURE update_category(
      c_id   IN category.categoryid%type,
      c_name IN category.categoryName%type,
      c_desc IN category.categorydescription%type);
  PROCEDURE delete_category(
      c_id IN category.categoryid%type);
  PROCEDURE addcategory(
      c_categoryName        IN VARCHAR2,
      c_categoryDescription IN VARCHAR2 DEFAULT NULL);
  PROCEDURE find_category_by_id(
      c_id IN category.categoryid%type,
      c_name OUT category.categoryname%type,
      c_desc OUT category.categorydescription%type );
END P_CATEGORY;