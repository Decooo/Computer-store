create TYPE category_type as object(
categoryID Number(10),
categoryName varchar2(50),
categoryDescription varchar2(255));