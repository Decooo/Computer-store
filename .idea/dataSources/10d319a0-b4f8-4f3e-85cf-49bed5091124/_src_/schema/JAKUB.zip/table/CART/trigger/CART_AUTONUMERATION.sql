create trigger CART_AUTONUMERATION
	before insert
	on CART
	for each row
BEGIN
      :new.cartID:=CART_SEQ.nextval;
    END;