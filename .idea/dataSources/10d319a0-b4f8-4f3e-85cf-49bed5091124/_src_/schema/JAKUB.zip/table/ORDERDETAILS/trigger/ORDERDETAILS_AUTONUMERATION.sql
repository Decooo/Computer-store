create trigger ORDERDETAILS_AUTONUMERATION
	before insert
	on ORDERDETAILS
	for each row
BEGIN
      :new.orderDetailsID:=ORDERDETAILS_SEQ.nextval;
    END;