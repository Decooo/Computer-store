create trigger CLIENT_AUTONUMERATION
	before insert
	on CLIENT
	for each row
BEGIN
      :new.clientID:=CLIENT_SEQ.nextval;
    END;