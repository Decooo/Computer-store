create PROCEDURE add_product_to_cart(
    userID     IN cart.userID%type,
    productID  IN cart.productID%type,
    quantity   IN cart.quantity%type,
    totalprice IN cart.quantity%type)
IS
BEGIN
  INSERT
  INTO cart
    (
      userID,
      productID,
      quantity,
      totalprice
    )
    VALUES
    (
      userID,
      productID,
      quantity,
      totalprice
    );
END ;