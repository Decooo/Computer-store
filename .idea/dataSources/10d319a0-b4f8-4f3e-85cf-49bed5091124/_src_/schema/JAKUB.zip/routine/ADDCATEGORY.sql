create PROCEDURE addcategory(
    c_categoryName        IN VARCHAR2,
    c_categoryDescription IN VARCHAR2 DEFAULT NULL)
IS
BEGIN
  INSERT
  INTO category
    (
      categoryName,
      categoryDescription
    )
    VALUES
    (
      c_categoryName,
      c_categoryDescription
    );
END addcategory;