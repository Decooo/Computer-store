create PROCEDURE delete_category(
    c_id IN category.categoryid%type)
AS
BEGIN
  DELETE FROM category WHERE categoryID=c_id;
END;