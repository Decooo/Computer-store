create FUNCTION VIEWALLCATEGORIES
Return VARCHAR2 AS 
myresult category.categoryName%TYPE;
BEGIN
  select category.categoryName
  into myresult
  from category
  where category.categoryID = 3;
  
  DBMS_OUTPUT.PUT_LINE('myresult = ' || myresult);

  return myresult;
  
END VIEWALLCATEGORIES;