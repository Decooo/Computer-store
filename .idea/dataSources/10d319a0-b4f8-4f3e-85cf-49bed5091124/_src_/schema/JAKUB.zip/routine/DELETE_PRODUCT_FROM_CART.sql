create PROCEDURE delete_product_from_cart(
    c_id IN cart.cartid%type)
AS
BEGIN
  DELETE FROM cart WHERE cartid=c_id;
END;