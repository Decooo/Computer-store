create PROCEDURE update_category(
    c_id   IN category.categoryid%type,
    c_name IN category.categoryName%type,
    c_desc IN category.categorydescription%type)
AS
BEGIN
  UPDATE category
  SET categoryname     =c_name,
    categorydescription=c_desc
  WHERE categoryID     =c_id;
END;