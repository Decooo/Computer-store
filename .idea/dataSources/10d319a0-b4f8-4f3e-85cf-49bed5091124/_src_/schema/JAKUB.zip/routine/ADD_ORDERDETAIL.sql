create PROCEDURE add_orderdetail(
    o_orderid   IN orderdetails.orderid%type,
    o_productid IN orderdetails.productid%type,
    o_quantity IN orderdetails.quantity%type,
    o_price IN orderdetails.price%type)
IS
BEGIN
  INSERT
  INTO orderdetails
    (
      orderid,
      productid,
      quantity,
      price
    )
    VALUES
    (
      o_orderid,
      o_productid,
      o_quantity,
      o_price
    );
END ;