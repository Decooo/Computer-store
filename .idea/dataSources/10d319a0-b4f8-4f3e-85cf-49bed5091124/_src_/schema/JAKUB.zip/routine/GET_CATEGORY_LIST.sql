create PROCEDURE GET_CATEGORY_LIST 
(
  C_ID OUT NUMBER  
, C_NAME OUT VARCHAR2  
, C_DESC OUT VARCHAR2  
) AS 
BEGIN
  SELECT categoryID,categoryName,categoryDescription into c_id,c_name,c_desc from category where categoryid=5;
END GET_CATEGORY_LIST;