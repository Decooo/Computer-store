create FUNCTION add_quantity(
      c_id IN cart.quantity%type)
    RETURN INTEGER
  AS
    myresult cart.quantity%type;
  BEGIN
    SELECT cart.quantity INTO myresult FROM cart WHERE cart.cartID= c_id;
    IF myresult != 0 THEN
      myresult  := myresult +1;
    END IF;
    DBMS_OUTPUT.PUT_LINE('myresult = ' || myresult);
    update_quantity(myresult,c_id);
    RETURN myresult;
  END add_quantity;