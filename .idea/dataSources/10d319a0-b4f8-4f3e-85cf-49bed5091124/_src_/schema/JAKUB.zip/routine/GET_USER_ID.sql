create PROCEDURE get_user_id(
    u_id OUT users.userid%type,
    u_username IN users.username%type)
IS
BEGIN
  SELECT userID INTO u_id FROM users WHERE username=u_username;
EXCEPTION
WHEN no_data_found THEN
  u_id:=-1;
END;