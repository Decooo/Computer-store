create procedure get_user_id
(u_id out users.userid%type,
u_username in users.username%type)
is
begin
Select userID into u_id from users where username=u_username;

EXCEPTION
    WHEN no_data_found THEN
    u_id:=-1;

end;