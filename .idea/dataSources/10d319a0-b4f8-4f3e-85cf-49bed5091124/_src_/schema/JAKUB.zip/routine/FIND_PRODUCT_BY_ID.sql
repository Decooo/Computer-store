create PROCEDURE find_product_by_id(
    p_id IN product.productid%type,
    p_name OUT product.productname%type,
    p_desc OUT product.productdescription%type,
    p_price OUT product.productprice%type,
    p_picture OUT product.picture%type,
    p_cat OUT product.categoryid%type)
IS
BEGIN
  SELECT productname,
    productdescription,
    productprice,
    picture,
    categoryid
  INTO p_name,
    p_desc,
    p_price,
    p_picture,
    p_cat
  FROM product
  WHERE productid=p_id;
END;