create function get_category
return category%rowtype as allcategory category%rowtype;
CURSOR KURSOR IS
select * FROM category;
BEGIN
open kursor;
  loop
  fetch kursor into allcategory;
  exit when kursor%notfound;
  dbms_output.put_line('Id_ kategorii: '||allcategory.categoryID||' nazwa_kategorii: '|| allcategory.categoryName||' opis_kategorii: '|| allcategory.categoryDescription);
  end loop;
close kursor;
return allcategory;
end;