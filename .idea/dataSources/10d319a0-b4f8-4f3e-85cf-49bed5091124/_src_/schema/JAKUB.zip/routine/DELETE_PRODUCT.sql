create PROCEDURE delete_product(
    p_id IN product.productid%type)
AS
BEGIN
  DELETE FROM product WHERE productID=p_id;
END;