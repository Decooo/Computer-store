create PROCEDURE find_category_by_id(
    c_id IN category.categoryid%type,
    c_name OUT category.categoryname%type,
    c_desc OUT category.categorydescription%type)
IS
BEGIN
  SELECT categoryname,
    categorydescription
  INTO c_name,
    c_desc
  FROM category
  WHERE categoryid=c_id;
END;