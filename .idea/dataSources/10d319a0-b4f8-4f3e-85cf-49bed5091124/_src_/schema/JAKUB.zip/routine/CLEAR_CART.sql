create PROCEDURE clear_cart(
    c_id IN cart.userid%type)
AS
BEGIN
  DELETE FROM cart WHERE userID=c_id;
END;