create procedure get_amount(
      c_userID in cart.userID%type,
      c_totalPrice OUT cart.totalPrice%type)
AS
  BEGIN
Select sum(totalPrice*quantity) INTO c_totalPrice From cart where userid=c_userID;
  END get_amount;