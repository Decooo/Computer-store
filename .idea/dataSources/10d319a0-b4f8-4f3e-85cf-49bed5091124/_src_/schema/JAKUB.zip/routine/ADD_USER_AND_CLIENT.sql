create function add_user_and_Client
(u_username in users.username%type,u_password in users.password%type, c_firstname in client.firstname%type,
c_lastname in client.lastname%type, c_emailaddress in client.emailaddress%type, c_street in client.street%type,
c_numberhouse in client.numberhouse%type,c_postcode in client.postcode%type,c_city in client.city%type)
return client.clientid%type as c_clientID client.clientid%type;
begin
insert into client(firstname,lastname,street,numberhouse,postcode,city)
values(c_firstname,c_lastname,c_street,c_numberhouse,c_postcode,c_city);

insert into users(username,password,clientID,userrole)
values(u_username,u_password,c_clientID,'user');

end;