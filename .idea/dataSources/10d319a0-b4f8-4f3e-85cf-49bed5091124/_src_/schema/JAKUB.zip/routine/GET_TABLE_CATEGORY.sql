create PROCEDURE get_table_category
IS
  kategorie CATEGORY%ROWTYPE;
  CURSOR MOJ_KURSOR
  IS
    SELECT * FROM CATEGORY;
BEGIN
  FOR kategorie IN MOJ_KURSOR
  LOOP
    dbms_output.put_line('categoryName: '||kategorie.categoryName||' categoryDescription: '|| kategorie.categoryDescription);
  END LOOP;
END;