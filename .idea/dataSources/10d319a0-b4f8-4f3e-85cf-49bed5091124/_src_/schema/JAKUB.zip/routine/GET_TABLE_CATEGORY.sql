create procedure get_table_category is 
kategorie CATEGORY%ROWTYPE;
CURSOR MOJ_KURSOR IS
select * FROM CATEGORY;
BEGIN
FOR kategorie IN MOJ_KURSOR LOOP
dbms_output.put_line('categoryName: '||kategorie.categoryName||' categoryDescription: '|| kategorie.categoryDescription);
end loop;
end;