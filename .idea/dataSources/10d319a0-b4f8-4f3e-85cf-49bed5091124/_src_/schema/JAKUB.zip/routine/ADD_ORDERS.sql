create PROCEDURE add_orders(
    o_userid IN orders.userid%type,
    o_price  IN orders.totalprice%type,
    o_orderid OUT orders.orderid%type )
IS
BEGIN
  INSERT
  INTO orders
    (
      orderdate,
      userid,
      totalprice
    )
    VALUES
    (
      get_date(),
      o_userid,
      o_price
    )
  RETURNING orderid
  INTO o_orderid;
END ;