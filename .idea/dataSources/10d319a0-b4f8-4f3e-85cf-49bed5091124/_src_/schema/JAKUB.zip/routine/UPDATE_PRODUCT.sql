create PROCEDURE update_product(
    p_id      IN product.productid%type,
    p_name    IN product.productname%type,
    p_desc    IN product.productdescription%type,
    p_price   IN product.productprice%type,
    p_picture IN product.picture%type,
    p_cat     IN product.categoryid%type)
AS
BEGIN
  UPDATE product
  SET productname     =p_name,
    productdescription=p_desc,
    productprice      =p_price,
    picture           =p_picture,
    categoryid        =p_cat
  WHERE productID     =p_id;
END;