create procedure get_all_category
(allcategory OUT category%rowtype)is 
CURSOR KURSOR IS
select * FROM category;
BEGIN
open kursor;
  loop
  fetch kursor into allcategory;
  exit when kursor%notfound;
  dbms_output.put_line('Id_ kategorii: '||allcategory.categoryID||' nazwa_kategorii: '|| allcategory.categoryName||' opis_kategorii: '|| allcategory.categoryDescription);
  end loop;
close kursor;
end;