create PROCEDURE get_all_category(
    allcategory OUT category%rowtype)
IS
  CURSOR KURSOR
  IS
    SELECT * FROM category;
BEGIN
  OPEN kursor;
  LOOP
    FETCH kursor INTO allcategory;
    EXIT
  WHEN kursor%notfound;
    dbms_output.put_line('Id_ kategorii: '||allcategory.categoryID||' nazwa_kategorii: '|| allcategory.categoryName||' opis_kategorii: '|| allcategory.categoryDescription);
  END LOOP;
  CLOSE kursor;
END;