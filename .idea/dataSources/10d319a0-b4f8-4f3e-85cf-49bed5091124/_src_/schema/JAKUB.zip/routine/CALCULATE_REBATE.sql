create FUNCTION CALCULATE_REBATE(
      c_userid IN cart.userid%type,
      amount OUT cart.totalPrice%type)
    RETURN NUMBER
  AS
    rebate NUMBER;
  BEGIN
    SELECT SUM(totalPrice*quantity) INTO amount FROM cart WHERE userid=c_userID;
    IF amount    <500 THEN
      rebate    :=0;
    elsif amount>=500 AND amount<3000 THEN
      rebate    :=amount*0.03;
    elsif amount>=3000 AND amount<5000 THEN
      rebate    :=amount*0.05;
    elsif amount>=5000 AND amount<8000 THEN
      rebate    :=amount*0.08;
    elsif amount>=8000 THEN
      rebate    :=amount*0.1;
    END IF;
    RETURN rebate;
  END CALCULATE_REBATE;