create PROCEDURE add_product(
    p_name  IN product.productname%type,
    p_desc  IN product.productdescription%type,
    p_price IN product.productprice%type,
    picture IN product.picture%type,
    cat     IN product.categoryid%type)
IS
BEGIN
  INSERT
  INTO product
    (
      productname,
      productDescription,
      productprice,
      picture,
      categoryid
    )
    VALUES
    (
      p_name,
      p_desc,
      p_price,
      picture,
      cat
    );
END ;