create PROCEDURE update_quantity(
    c_quantity IN cart.quantity%type,
    c_id       IN cart.cartid%type )
AS
BEGIN
  UPDATE cart SET quantity =c_quantity WHERE cartID =c_id;
END;