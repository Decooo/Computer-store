create trigger AUTO_ID_SERIA
	before insert
	on SERIA
	for each row
BEGIN
  SELECT AUTO_ID_SERIA.nextval into :NEW.ID_SERI FROM DUAL