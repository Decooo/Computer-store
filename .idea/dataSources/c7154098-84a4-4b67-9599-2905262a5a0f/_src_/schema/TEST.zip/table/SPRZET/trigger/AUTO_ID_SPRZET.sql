create trigger AUTO_ID_SPRZET
	before insert
	on SPRZET
	for each row
BEGIN
  SELECT AUTO_ID_SPRZET.nextval into :NEW.ID_SPRZETU FROM DUAL