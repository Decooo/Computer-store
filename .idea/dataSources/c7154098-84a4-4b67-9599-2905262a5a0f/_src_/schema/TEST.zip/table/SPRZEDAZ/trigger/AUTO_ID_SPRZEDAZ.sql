create trigger AUTO_ID_SPRZEDAZ
	before insert
	on SPRZEDAZ
	for each row
BEGIN
  SELECT AUTO_ID_SPRZEDAZ.nextval into :NEW.ID_SPRZEDAZY FROM DUAL