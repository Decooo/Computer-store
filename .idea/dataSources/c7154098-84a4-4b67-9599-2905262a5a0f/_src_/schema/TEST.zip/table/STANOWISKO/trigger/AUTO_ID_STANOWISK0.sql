create trigger AUTO_ID_STANOWISK0
	before insert
	on STANOWISKO
	for each row
BEGIN
  SELECT AUTO_ID_STANOWISKO.nextval into :NEW.id_stanowiska FROM DUAL