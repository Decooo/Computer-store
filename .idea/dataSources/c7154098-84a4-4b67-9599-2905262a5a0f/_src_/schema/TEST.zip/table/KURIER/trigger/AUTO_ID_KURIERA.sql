create trigger AUTO_ID_KURIERA
	before insert
	on KURIER
	for each row
BEGIN
  SELECT AUTO_ID_KURIERA.nextval into :NEW.ID_KURIERA FROM DUAL