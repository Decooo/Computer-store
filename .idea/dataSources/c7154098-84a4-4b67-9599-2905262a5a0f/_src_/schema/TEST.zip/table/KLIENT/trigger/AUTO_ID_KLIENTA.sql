create trigger AUTO_ID_KLIENTA
	before insert
	on KLIENT
	for each row
BEGIN
  SELECT AUTO_ID_KLIENTA.nextval into :NEW.ID_KLIENTA FROM DUAL